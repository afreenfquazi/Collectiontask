package com.practice.CollectionsProblem;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

public class EmployeeService {

	List<Employee> list = EmployeeRepository.getEmployees();
	Employee emp = null;

	public Employee getEmployee(int id, String name) {

		Iterator<Employee> itr = list.iterator();

		while (itr.hasNext()) {
			emp = itr.next();
			if (emp.getId() == id) {
				break;
			}
		}

		return emp;

	}

	public List<String> getEmployees(Double salary) {
		// display the names of employees who are getting the salary greater than the
		// salary given
		Double sal = 0.0;
		List<String> l = new ArrayList<>();

		Iterator<Employee> itr = list.iterator();
		while (itr.hasNext()) {
			emp = itr.next();
			sal = emp.getSalary();
			if (sal > salary) {
				l.add(emp.getName());
			}
		}

		return l;
	}

	public Double getMaxSalary() {
		Double max = 0.0;
		Iterator<Employee> itr = list.iterator();
		while(itr.hasNext()) {
			emp = itr.next();
			if(emp.getSalary()>max)
			{
				max=emp.getSalary();
			}
		}
		return max;

	}

	public Double getSumOfSalary() {
		// display the sum of salaries of all the employees
		Double total = 0.0;
		Iterator<Employee>itr = list.iterator();
		while(itr.hasNext()) {
			emp = itr.next();
			total= emp.getSalary()+total;
		}
		return total;

	}

	public List<String> getNames(String city) {
		// display the names of all employees who are working in 'Pune'
		List<String> l = new ArrayList<>();
		Iterator<Employee> itr = list.iterator();
		while(itr.hasNext()) {
			emp = itr.next();
			if(emp.getLocation()=="Pune") {
				l.add(emp.getName());
			}
		}
		return l;
	}

	public List<Employee> getDetails() {
		//List<Employee> l = new ArrayList<>();

		return list;
	}

	public List<Employee> getManagers() {
		// display all employees who are working as managers
		List<Employee> l = new ArrayList<>();
		Iterator<Employee> itr  = list.iterator();
		while(itr.hasNext()) {
			emp = itr.next();
			if(emp.getDesignation()=="Manager") {
				l.add(emp);
			}
		}
		return l;
	}

	public Double getSumOfManagerSalaries() {
		// display the sum of salaries of employees who are working as managers
		Double sum = 0.0;
		Iterator<Employee> itr = list.iterator();
		while(itr.hasNext()) {
			emp = itr.next();
			if(emp.getDesignation()=="Manager") {
				sum= sum+emp.getSalary();
			}
			
		}
		return sum;
	}

	public List<Integer> getIds() {
		// display the ids of all employees
		List<Integer> l = new ArrayList<>();
		Iterator<Employee> itr = list.iterator();
		while(itr.hasNext()) {
			emp= itr.next();
			l.add(emp.getId());
		}

		return l;
	}
}
