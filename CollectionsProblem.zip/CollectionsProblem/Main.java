package com.practice.CollectionsProblem;

public class Main {

	public static void main(String[] args) {

		EmployeeService service = new EmployeeService();
		System.out.println("Get max salary of the employee " + service.getMaxSalary());
		System.out.println("Details of employees "+service.getDetails());
		System.out.println("Particular employee details " + service.getEmployee(129087, "Rahul Vikas"));
		System.out.println("Sum of managers salary " +service.getSumOfManagerSalaries());
		System.out.println("Employee getting salaries more than 70000 " + service.getEmployees(70000.00));
		System.out.println("Sum of the salaries " + service.getSumOfSalary());
		System.out.println("Ids of the employee "+service.getIds());
		System.out.println("Employees who are working as manager "+service.getManagers());
		System.out.println("Name of employee who are located in Pune "+service.getNames("Pune"));
	}

}
